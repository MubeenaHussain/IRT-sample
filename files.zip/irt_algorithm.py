"""
Item Response Theory (IRT) - 2 Parameter Logistic (2PL) Model
==============================================================

Model: P(θ) = 1 / (1 + exp(-a * (θ - b)))

Parameters:
  θ (theta)  — Student ability (typically in range [-4, 4])
  a          — Item discrimination (how well item differentiates abilities)
  b          — Item difficulty (ability level where P = 0.5)

Ability Estimation: Maximum Likelihood Estimation (MLE) via Newton-Raphson
"""

import math
from typing import List, Tuple


# ─── Core IRT Math ────────────────────────────────────────────────────────────

def probability(theta: float, a: float, b: float) -> float:
    """
    2PL probability: P(correct | theta, a, b)
    """
    exponent = -a * (theta - b)
    # Clamp to avoid overflow
    exponent = max(-500, min(500, exponent))
    return 1.0 / (1.0 + math.exp(exponent))


def log_likelihood(theta: float, responses: List[dict]) -> float:
    """
    Log-likelihood of theta given a list of item responses.
    responses: [{"a": ..., "b": ..., "correct": 0|1}, ...]
    """
    ll = 0.0
    for r in responses:
        p = probability(theta, r["a"], r["b"])
        p = max(1e-10, min(1 - 1e-10, p))  # Numerical stability
        if r["correct"] == 1:
            ll += math.log(p)
        else:
            ll += math.log(1 - p)
    return ll


def score_to_theta(correct: int, total: int) -> float:
    """
    Rough starting theta based on proportion correct.
    Maps [0, 1] → [-3, 3] with logit transform.
    """
    if total == 0:
        return 0.0
    p = correct / total
    p = max(0.01, min(0.99, p))
    return math.log(p / (1 - p))


# ─── MLE Estimation (Newton-Raphson) ──────────────────────────────────────────

def estimate_theta_mle(
    responses: List[dict],
    max_iter: int = 50,
    tol: float = 1e-6,
    theta_min: float = -4.0,
    theta_max: float = 4.0,
) -> Tuple[float, float, int]:
    """
    Estimate ability (theta) via Maximum Likelihood Estimation.

    Uses Newton-Raphson iteration:
      theta_new = theta - L'(theta) / L''(theta)

    Returns:
      (theta_hat, se, iterations)
      - theta_hat: estimated ability
      - se: standard error of estimate
      - iterations: number of NR iterations used
    """
    correct = sum(1 for r in responses if r["correct"] == 1)
    total = len(responses)

    # Edge cases: all correct / all wrong → clamp to boundary
    if correct == 0:
        return theta_min, 1.0, 0
    if correct == total:
        return theta_max, 1.0, 0

    # Starting point
    theta = score_to_theta(correct, total)
    theta = max(theta_min, min(theta_max, theta))

    for iteration in range(max_iter):
        first_deriv = 0.0   # L'(theta)
        second_deriv = 0.0  # L''(theta)

        for r in responses:
            p = probability(theta, r["a"], r["b"])
            p = max(1e-10, min(1 - 1e-10, p))
            w = p * (1 - p)

            if r["correct"] == 1:
                first_deriv += r["a"] * (1 - p)
            else:
                first_deriv += r["a"] * (-p)

            second_deriv -= (r["a"] ** 2) * w

        # Avoid division by zero
        if abs(second_deriv) < 1e-10:
            break

        delta = first_deriv / second_deriv
        theta -= delta
        theta = max(theta_min, min(theta_max, theta))

        if abs(delta) < tol:
            break

    # Standard error = 1 / sqrt(Fisher information)
    fisher_info = sum(
        (r["a"] ** 2) * probability(theta, r["a"], r["b"]) * (1 - probability(theta, r["a"], r["b"]))
        for r in responses
    )
    se = 1.0 / math.sqrt(max(fisher_info, 1e-10))

    return round(theta, 4), round(se, 4), iteration + 1


# ─── Item Information ──────────────────────────────────────────────────────────

def item_information(theta: float, a: float, b: float) -> float:
    """
    Fisher information for a single item at ability theta.
    I(theta) = a^2 * P(theta) * (1 - P(theta))
    """
    p = probability(theta, a, b)
    return (a ** 2) * p * (1 - p)


def test_information(theta: float, items: List[dict]) -> float:
    """
    Total test information at ability theta.
    """
    return sum(item_information(theta, item["a"], item["b"]) for item in items)


# ─── Ability Classification ────────────────────────────────────────────────────

def classify_ability(theta: float) -> str:
    """Map theta to a human-readable ability band."""
    if theta >= 2.0:
        return "Advanced"
    elif theta >= 0.5:
        return "Proficient"
    elif theta >= -0.5:
        return "Basic"
    elif theta >= -2.0:
        return "Below Basic"
    else:
        return "Minimal"


# ─── Adaptive Item Selection (CAT helper) ─────────────────────────────────────

def select_next_item(theta: float, available_items: List[dict]) -> dict:
    """
    Maximum Information Criterion: pick the item with highest
    Fisher information at the current theta estimate.
    Returns the best item dict.
    """
    return max(
        available_items,
        key=lambda item: item_information(theta, item["a"], item["b"])
    )


# ─── Batch Scoring ─────────────────────────────────────────────────────────────

def score_student(student_responses: List[dict]) -> dict:
    """
    Full IRT scoring for one student.

    student_responses: [
        {"item_id": 1, "a": 1.2, "b": 0.5, "correct": 1},
        ...
    ]

    Returns a scoring summary dict.
    """
    total = len(student_responses)
    correct = sum(1 for r in student_responses if r["correct"] == 1)

    theta, se, iters = estimate_theta_mle(student_responses)

    items_for_info = [{"a": r["a"], "b": r["b"]} for r in student_responses]
    t_info = test_information(theta, items_for_info)

    return {
        "theta": theta,
        "standard_error": se,
        "reliability": round(1 - (se ** 2), 4),
        "test_information": round(t_info, 4),
        "ability_level": classify_ability(theta),
        "raw_score": correct,
        "total_items": total,
        "percent_correct": round(correct / total * 100, 1) if total else 0,
        "nr_iterations": iters,
    }
