"""
Dummy IRT data for MVP testing.
Covers a range of item difficulties and student abilities.
"""

# ─── Dummy Items ───────────────────────────────────────────────────────────────
# a: discrimination (0.5–2.0), b: difficulty (-3 to 3)

DUMMY_ITEMS = [
    # Very Easy (b ≈ -2.0)
    {"id": 1,  "title": "Basic Addition",          "a": 0.8, "b": -2.5, "subject": "math"},
    {"id": 2,  "title": "Simple Subtraction",      "a": 0.9, "b": -2.0, "subject": "math"},
    {"id": 3,  "title": "Number Recognition",      "a": 0.7, "b": -2.2, "subject": "math"},

    # Easy (b ≈ -1.0)
    {"id": 4,  "title": "Multiplication Basics",   "a": 1.1, "b": -1.2, "subject": "math"},
    {"id": 5,  "title": "Simple Fractions",        "a": 1.2, "b": -0.8, "subject": "math"},

    # Medium (b ≈ 0.0)
    {"id": 6,  "title": "Linear Equations",        "a": 1.4, "b": -0.3, "subject": "math"},
    {"id": 7,  "title": "Area & Perimeter",        "a": 1.3, "b":  0.1, "subject": "math"},
    {"id": 8,  "title": "Ratios & Proportions",    "a": 1.5, "b":  0.4, "subject": "math"},

    # Hard (b ≈ 1.0)
    {"id": 9,  "title": "Quadratic Equations",     "a": 1.6, "b":  0.9, "subject": "math"},
    {"id": 10, "title": "Systems of Equations",    "a": 1.4, "b":  1.3, "subject": "math"},

    # Very Hard (b ≈ 2.0+)
    {"id": 11, "title": "Calculus Derivatives",    "a": 1.8, "b":  2.0, "subject": "math"},
    {"id": 12, "title": "Integration Problems",    "a": 1.7, "b":  2.5, "subject": "math"},
    {"id": 13, "title": "Vector Operations",       "a": 2.0, "b":  1.8, "subject": "math"},
    {"id": 14, "title": "Complex Proofs",          "a": 1.9, "b":  3.0, "subject": "math"},

    # Mixed difficulty (medium-high)
    {"id": 15, "title": "Trigonometry Basics",     "a": 1.5, "b":  0.7, "subject": "math"},
]


# ─── Dummy Students ────────────────────────────────────────────────────────────
# true_theta: the student's actual ability (used in simulation)

DUMMY_STUDENTS = [
    {"student_id": "S001", "name": "Alice Chen",    "grade": 12, "true_theta":  2.5},
    {"student_id": "S002", "name": "Bob Martinez",  "grade": 12, "true_theta":  1.5},
    {"student_id": "S003", "name": "Carol Kim",     "grade": 11, "true_theta":  0.7},
    {"student_id": "S004", "name": "David Osei",    "grade": 11, "true_theta":  0.0},
    {"student_id": "S005", "name": "Emma Thompson", "grade": 10, "true_theta": -0.5},
    {"student_id": "S006", "name": "Frank Liu",     "grade": 10, "true_theta": -1.2},
    {"student_id": "S007", "name": "Grace Park",    "grade":  9, "true_theta": -2.0},
    {"student_id": "S008", "name": "Henry Brown",   "grade":  9, "true_theta": -3.0},
]


# ─── Django Fixture Format ─────────────────────────────────────────────────────

FIXTURE_ITEMS = [
    {
        "model": "irt_app.item",
        "pk": item["id"],
        "fields": {
            "title": item["title"],
            "subject": item["subject"],
            "question_text": f"This is a placeholder question for: {item['title']}",
            "option_a": "Option A (correct)",
            "option_b": "Option B",
            "option_c": "Option C",
            "option_d": "Option D",
            "correct_option": "A",
            "a_param": item["a"],
            "b_param": item["b"],
            "is_active": True,
        }
    }
    for item in DUMMY_ITEMS
]

FIXTURE_STUDENTS = [
    {
        "model": "irt_app.student",
        "pk": i + 1,
        "fields": {
            "user": None,
            "student_id": s["student_id"],
            "name": s["name"],
            "grade": s["grade"],
            "theta_estimate": 0.0,
            "standard_error": 1.0,
            "ability_level": "Basic",
        }
    }
    for i, s in enumerate(DUMMY_STUDENTS)
]
