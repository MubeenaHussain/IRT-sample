# IRT Django MVP — Item Response Theory with 2PL Model

## Model: 2-Parameter Logistic (2PL)

```
P(θ) = 1 / (1 + exp(-a × (θ - b)))
```

| Symbol | Name | Range | Meaning |
|--------|------|--------|---------|
| θ (theta) | Student ability | [-4, 4] | Higher = more capable |
| a | Discrimination | [0.5, 2.5] | How well item separates abilities |
| b | Difficulty | [-3, 3] | θ level where P(correct) = 0.5 |

**Estimation**: Maximum Likelihood Estimation via Newton-Raphson iteration.

---

## Setup

```bash
pip install django

cd irt_django
python manage.py makemigrations irt_app
python manage.py migrate
python manage.py seed_irt_data      # loads 15 items + 8 students
python manage.py runserver
```

---

## API Endpoints

### Pure Algorithm Demo (no auth, no DB writes)
```
GET /api/demo/
```
Simulates all 8 dummy students answering 15 items and returns IRT scores.

---

### Items
```
GET /api/items/                    # all items
GET /api/items/?subject=math       # filter by subject
```

### Students
```
GET /api/students/                 # all students with theta estimates
```

### Test Sessions

**1. Start session**
```
POST /api/sessions/start/
{"student_id": "S001", "subject": "math"}
```
Returns session ID + first item suggestion (maximum information criterion).

**2. Submit answer**
```
POST /api/sessions/1/respond/
{"item_id": 6, "selected_option": "A"}
```
Returns correctness + interim theta + next best item.

**3. Score session (IRT)**
```
POST /api/sessions/1/score/
```
Runs full MLE, saves theta to student record.

**4. View results**
```
GET /api/sessions/1/result/
```

---

## Project Structure

```
irt_django/
├── manage.py
├── irt_project/
│   ├── settings.py
│   └── urls.py
└── irt_app/
    ├── irt_algorithm.py      ← Core IRT math (no dependencies)
    ├── dummy_data.py         ← 15 items + 8 students with true theta
    ├── models.py             ← Item, Student, TestSession, Response
    ├── views.py              ← REST API views
    ├── urls.py
    ├── admin.py
    └── management/commands/
        └── seed_irt_data.py
```

---

## IRT Algorithm Flow

```
Student answers items
        ↓
For each item: P(θ) = 1 / (1 + exp(-a(θ - b)))
        ↓
Log-likelihood: L(θ) = Σ [u_i·ln(P_i) + (1-u_i)·ln(1-P_i)]
        ↓
Newton-Raphson: θ_new = θ - L'(θ) / L''(θ)  [iterate until |Δθ| < 1e-6]
        ↓
Standard Error: SE = 1 / √I(θ)  where I(θ) = Σ a_i² · P_i · (1-P_i)
        ↓
Output: θ_hat, SE, ability_level, reliability = 1 - SE²
```

---

## Adaptive Item Selection (CAT-ready)

After each response, the next item is selected by **maximum Fisher information**:

```
I_j(θ) = a_j² × P_j(θ) × (1 - P_j(θ))
```

Pick item j that maximises `I_j(θ̂)`. This is the core of Computerised Adaptive Testing (CAT).

---

## Next Steps (beyond MVP)

- [ ] 3PL model (add guessing parameter `c`)
- [ ] EAP estimation with prior distribution
- [ ] Item calibration (estimate a/b from response data)
- [ ] Stopping rules for CAT (SE threshold, max items)
- [ ] DIF analysis (differential item functioning)
- [ ] JWT auth + per-user session isolation
