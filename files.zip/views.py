"""
IRT API Views
=============
Endpoints:
  GET  /api/items/              — List all active items
  GET  /api/students/           — List all students with ability estimates
  POST /api/sessions/start/     — Start a new test session
  POST /api/sessions/<id>/respond/ — Submit an answer
  POST /api/sessions/<id>/score/   — Score session with IRT
  GET  /api/sessions/<id>/result/  — View full IRT result
  GET  /api/demo/               — Run a full demo with dummy data
"""

import json
from datetime import datetime, timezone

from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.shortcuts import get_object_or_404

from .models import Item, Student, TestSession, Response
from .irt_algorithm import score_student, select_next_item, estimate_theta_mle, item_information


# ─── Helpers ──────────────────────────────────────────────────────────────────

def json_body(request):
    try:
        return json.loads(request.body)
    except (json.JSONDecodeError, ValueError):
        return {}


def item_to_dict(item):
    return {
        "id": item.pk,
        "title": item.title,
        "subject": item.subject,
        "question_text": item.question_text,
        "options": {
            "A": item.option_a,
            "B": item.option_b,
            "C": item.option_c,
            "D": item.option_d,
        },
        "irt_params": {
            "a": item.a_param,
            "b": item.b_param,
            "difficulty_label": _difficulty_label(item.b_param),
        },
    }


def _difficulty_label(b: float) -> str:
    if b <= -1.5:
        return "Very Easy"
    elif b <= -0.5:
        return "Easy"
    elif b <= 0.5:
        return "Medium"
    elif b <= 1.5:
        return "Hard"
    else:
        return "Very Hard"


# ─── Item Views ────────────────────────────────────────────────────────────────

@method_decorator(csrf_exempt, name="dispatch")
class ItemListView(View):
    def get(self, request):
        subject = request.GET.get("subject")
        qs = Item.objects.filter(is_active=True)
        if subject:
            qs = qs.filter(subject=subject)
        return JsonResponse({"items": [item_to_dict(i) for i in qs]})


# ─── Student Views ─────────────────────────────────────────────────────────────

@method_decorator(csrf_exempt, name="dispatch")
class StudentListView(View):
    def get(self, request):
        students = Student.objects.all()
        data = []
        for s in students:
            data.append({
                "id": s.pk,
                "student_id": s.student_id,
                "name": s.name,
                "grade": s.grade,
                "theta": s.theta_estimate,
                "standard_error": s.standard_error,
                "ability_level": s.ability_level,
            })
        return JsonResponse({"students": data})


# ─── Session Views ─────────────────────────────────────────────────────────────

@method_decorator(csrf_exempt, name="dispatch")
class StartSessionView(View):
    """
    POST /api/sessions/start/
    Body: {"student_id": "S001", "subject": "math"}
    """
    def post(self, request):
        data = json_body(request)
        student_id = data.get("student_id")
        subject = data.get("subject", "math")

        try:
            student = Student.objects.get(student_id=student_id)
        except Student.DoesNotExist:
            return JsonResponse({"error": f"Student '{student_id}' not found."}, status=404)

        session = TestSession.objects.create(student=student, subject=subject)

        # Suggest first item based on student's current theta
        available = list(Item.objects.filter(is_active=True, subject=subject).values(
            "id", "a_param", "b_param"
        ))
        first_item = None
        if available:
            best = select_next_item(
                student.theta_estimate,
                [{"id": x["id"], "a": x["a_param"], "b": x["b_param"]} for x in available]
            )
            item = Item.objects.get(pk=best["id"])
            first_item = item_to_dict(item)

        return JsonResponse({
            "session_id": session.pk,
            "student": student.name,
            "subject": subject,
            "current_theta": student.theta_estimate,
            "suggested_first_item": first_item,
        }, status=201)


@method_decorator(csrf_exempt, name="dispatch")
class RespondView(View):
    """
    POST /api/sessions/<session_id>/respond/
    Body: {"item_id": 3, "selected_option": "B"}
    """
    def post(self, request, session_id):
        session = get_object_or_404(TestSession, pk=session_id)
        if session.status == "completed":
            return JsonResponse({"error": "Session already completed."}, status=400)

        data = json_body(request)
        item_id = data.get("item_id")
        selected = data.get("selected_option", "").upper()

        try:
            item = Item.objects.get(pk=item_id)
        except Item.DoesNotExist:
            return JsonResponse({"error": f"Item {item_id} not found."}, status=404)

        if Response.objects.filter(session=session, item=item).exists():
            return JsonResponse({"error": "Already responded to this item."}, status=400)

        resp = Response.objects.create(session=session, item=item, selected_option=selected)

        # Interim theta estimate after each response
        all_responses = [{
            "a": r.item.a_param,
            "b": r.item.b_param,
            "correct": int(r.is_correct),
        } for r in session.responses.select_related("item").all()]

        theta, se, _ = estimate_theta_mle(all_responses) if len(all_responses) >= 2 else (
            session.student.theta_estimate, 1.0, 0
        )

        # Select next best item (exclude already answered)
        answered_ids = list(session.responses.values_list("item_id", flat=True))
        remaining = list(
            Item.objects.filter(is_active=True, subject=session.subject)
            .exclude(pk__in=answered_ids)
            .values("id", "a_param", "b_param")
        )
        next_item = None
        if remaining:
            best = select_next_item(
                theta,
                [{"id": x["id"], "a": x["a_param"], "b": x["b_param"]} for x in remaining]
            )
            next_item = item_to_dict(Item.objects.get(pk=best["id"]))

        return JsonResponse({
            "correct": resp.is_correct,
            "correct_option": item.correct_option,
            "interim_theta": theta,
            "interim_se": se,
            "items_answered": len(all_responses),
            "items_remaining": len(remaining),
            "next_suggested_item": next_item,
        })


@method_decorator(csrf_exempt, name="dispatch")
class ScoreSessionView(View):
    """
    POST /api/sessions/<session_id>/score/
    Runs full IRT scoring and saves results.
    """
    def post(self, request, session_id):
        session = get_object_or_404(TestSession, pk=session_id)

        if session.responses.count() == 0:
            return JsonResponse({"error": "No responses to score."}, status=400)

        responses_data = [{
            "item_id": r.item_id,
            "a": r.item.a_param,
            "b": r.item.b_param,
            "correct": int(r.is_correct),
        } for r in session.responses.select_related("item").all()]

        result = score_student(responses_data)

        # Save to session
        session.final_theta = result["theta"]
        session.final_se = result["standard_error"]
        session.raw_score = result["raw_score"]
        session.total_items = result["total_items"]
        session.reliability = result["reliability"]
        session.test_information = result["test_information"]
        session.ability_level = result["ability_level"]
        session.status = "completed"
        session.completed_at = datetime.now(timezone.utc)
        session.save()

        # Update student's ability estimate
        student = session.student
        student.theta_estimate = result["theta"]
        student.standard_error = result["standard_error"]
        student.ability_level = result["ability_level"]
        student.save()

        return JsonResponse({"session_id": session_id, "irt_result": result})


@method_decorator(csrf_exempt, name="dispatch")
class SessionResultView(View):
    """
    GET /api/sessions/<session_id>/result/
    """
    def get(self, request, session_id):
        session = get_object_or_404(TestSession, pk=session_id)

        item_details = []
        for r in session.responses.select_related("item").order_by("responded_at"):
            item_details.append({
                "item_id": r.item_id,
                "title": r.item.title,
                "a_param": r.item.a_param,
                "b_param": r.item.b_param,
                "selected": r.selected_option,
                "correct_option": r.item.correct_option,
                "is_correct": r.is_correct,
            })

        return JsonResponse({
            "session_id": session_id,
            "student": session.student.name,
            "subject": session.subject,
            "status": session.status,
            "irt_result": {
                "theta": session.final_theta,
                "standard_error": session.final_se,
                "raw_score": session.raw_score,
                "total_items": session.total_items,
                "reliability": session.reliability,
                "test_information": session.test_information,
                "ability_level": session.ability_level,
            },
            "item_responses": item_details,
        })


# ─── Demo View ─────────────────────────────────────────────────────────────────

@method_decorator(csrf_exempt, name="dispatch")
class DemoView(View):
    """
    GET /api/demo/
    Runs a simulated IRT session for all dummy students and returns results.
    No DB writes — pure algorithm demonstration.
    """
    def get(self, request):
        from .dummy_data import DUMMY_ITEMS, DUMMY_STUDENTS

        results = []
        for student_data in DUMMY_STUDENTS:
            # Simulate responses: student answers based on their true ability
            import random
            import math

            true_theta = student_data["true_theta"]
            student_responses = []

            for item in DUMMY_ITEMS:
                # Probability of correct based on 2PL
                p = 1.0 / (1.0 + math.exp(-item["a"] * (true_theta - item["b"])))
                correct = 1 if random.random() < p else 0
                student_responses.append({
                    "item_id": item["id"],
                    "a": item["a"],
                    "b": item["b"],
                    "correct": correct,
                })

            irt_result = score_student(student_responses)

            results.append({
                "student": student_data["name"],
                "true_theta": true_theta,
                "estimated_theta": irt_result["theta"],
                "estimation_error": round(abs(true_theta - irt_result["theta"]), 4),
                "ability_level": irt_result["ability_level"],
                "raw_score": f"{irt_result['raw_score']}/{irt_result['total_items']}",
                "percent_correct": irt_result["percent_correct"],
                "standard_error": irt_result["standard_error"],
                "reliability": irt_result["reliability"],
            })

        return JsonResponse({
            "description": "IRT 2PL Demo — simulated responses based on true theta",
            "model": "2-Parameter Logistic (2PL)",
            "estimation_method": "Maximum Likelihood Estimation (Newton-Raphson)",
            "n_items": len(DUMMY_ITEMS),
            "results": results,
        })
