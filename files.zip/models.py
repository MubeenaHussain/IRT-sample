from django.db import models
from django.contrib.auth.models import User


class Item(models.Model):
    """
    A test item (question) with IRT parameters.
    """
    SUBJECT_CHOICES = [
        ("math", "Mathematics"),
        ("science", "Science"),
        ("english", "English"),
        ("history", "History"),
    ]

    title = models.CharField(max_length=255)
    subject = models.CharField(max_length=50, choices=SUBJECT_CHOICES, default="math")
    question_text = models.TextField()
    option_a = models.CharField(max_length=255)
    option_b = models.CharField(max_length=255)
    option_c = models.CharField(max_length=255)
    option_d = models.CharField(max_length=255)
    correct_option = models.CharField(
        max_length=1,
        choices=[("A", "A"), ("B", "B"), ("C", "C"), ("D", "D")]
    )

    # ── IRT Parameters ──
    # a: discrimination (0.5–2.5 typical)
    a_param = models.FloatField(
        default=1.0,
        help_text="Discrimination parameter (a). Higher = better differentiation."
    )
    # b: difficulty (-3 to 3 typical)
    b_param = models.FloatField(
        default=0.0,
        help_text="Difficulty parameter (b). Higher = harder item."
    )

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["subject", "b_param"]

    def __str__(self):
        return f"[{self.subject.upper()}] {self.title} (b={self.b_param:.2f})"


class Student(models.Model):
    """
    Represents a student / test-taker with their IRT ability estimate.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    student_id = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    grade = models.IntegerField(default=10)

    # ── Ability Estimates (updated after each session) ──
    theta_estimate = models.FloatField(
        default=0.0,
        help_text="Current IRT ability estimate (theta)."
    )
    standard_error = models.FloatField(
        default=1.0,
        help_text="Standard error of ability estimate."
    )
    ability_level = models.CharField(max_length=30, default="Basic")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.student_id}) — θ={self.theta_estimate:.3f}"


class TestSession(models.Model):
    """
    A single test-taking session for a student.
    """
    STATUS_CHOICES = [
        ("in_progress", "In Progress"),
        ("completed", "Completed"),
        ("abandoned", "Abandoned"),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="sessions")
    subject = models.CharField(max_length=50, default="math")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="in_progress")

    # ── IRT Results (filled after scoring) ──
    final_theta = models.FloatField(null=True, blank=True)
    final_se = models.FloatField(null=True, blank=True)
    raw_score = models.IntegerField(null=True, blank=True)
    total_items = models.IntegerField(null=True, blank=True)
    reliability = models.FloatField(null=True, blank=True)
    test_information = models.FloatField(null=True, blank=True)
    ability_level = models.CharField(max_length=30, blank=True)

    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Session #{self.pk} — {self.student.name} [{self.status}]"


class Response(models.Model):
    """
    A student's response to a single item within a session.
    """
    session = models.ForeignKey(TestSession, on_delete=models.CASCADE, related_name="responses")
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    selected_option = models.CharField(max_length=1, null=True, blank=True)
    is_correct = models.BooleanField(default=False)
    responded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("session", "item")

    def save(self, *args, **kwargs):
        # Auto-mark correctness
        if self.selected_option:
            self.is_correct = self.selected_option.upper() == self.item.correct_option.upper()
        super().save(*args, **kwargs)

    def __str__(self):
        status = "✓" if self.is_correct else "✗"
        return f"{status} Session#{self.session_id} → Item#{self.item_id}"
